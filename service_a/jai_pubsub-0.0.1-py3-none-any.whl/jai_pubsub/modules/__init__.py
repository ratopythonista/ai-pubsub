class JaiTask:
    def compile(self):
        raise NotImplementedError

    def run(self):
        raise NotImplementedError